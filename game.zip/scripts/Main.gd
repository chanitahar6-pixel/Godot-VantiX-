extends Node3D
@onready var score_label: Label = $UI/Score
var score := 0
func _ready() -> void:
    for coin in $Coins.get_children():
        coin.collected.connect(_on_coin_collected)
func _on_coin_collected() -> void:
    score += 1
    score_label.text = "SCORE  %d" % score
