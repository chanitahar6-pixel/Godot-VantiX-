extends Node3D

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Camera3D
@onready var distance_label: Label = $UI/TopBar/Margin/Row/Distance
@onready var left_button: Button = $UI/LeftButton
@onready var right_button: Button = $UI/RightButton
@onready var jump_button: Button = $UI/JumpButton
@onready var slide_button: Button = $UI/SlideButton

var distance_m := 0.0

func _ready() -> void:
    left_button.pressed.connect(player.move_left)
    right_button.pressed.connect(player.move_right)
    jump_button.pressed.connect(player.jump)
    slide_button.pressed.connect(player.slide)
    camera.global_position = player.global_position + Vector3(0, 3.05, 10)

func _process(delta: float) -> void:
    distance_m += max(0.0, -player.velocity.z) * delta
    distance_label.text = "%04d m" % int(distance_m)

    # Keep the camera locked to a fixed distance behind the runner.
    var desired := player.global_position + Vector3(0, 3.05, 10)
    camera.global_position.x = lerp(camera.global_position.x, desired.x, min(1.0, delta * 10.0))
    camera.global_position.y = lerp(camera.global_position.y, desired.y, min(1.0, delta * 8.0))
    camera.global_position.z = desired.z
    camera.look_at(player.global_position + Vector3(0, 1.0, -5.0), Vector3.UP)
