extends Node3D

const ROAD_SEGMENTS := 14
const ROAD_LENGTH := 60.0
const FOREST_SEGMENTS := 18
const FOREST_LENGTH := 34.0

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Camera3D

var distance_m := 0.0
var road_parts: Array[Node3D] = []
var forest_parts: Array[Node3D] = []
var rng := RandomNumberGenerator.new()
var mountain_rig: Node3D
var cloud_rig: Node3D
var hint_label: Label
var distance_label: Label

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    rng.seed = 918273
    _setup_lighting_and_sky()
    _build_road()
    _build_forest()
    _build_mountaintops()
    _build_clouds()
    _build_ui()
    camera.global_position = player.global_position + Vector3(0.0, 4.1, 10.5)
    camera.look_at(player.global_position + Vector3(0.0, 1.2, -12.0), Vector3.UP)

func _process(delta: float) -> void:
    distance_m = max(0.0, -player.global_position.z)
    if distance_label:
        distance_label.text = "%04d m" % int(distance_m)

    var desired := player.global_position + Vector3(0.0, 4.15, 10.5)
    camera.global_position.x = lerp(camera.global_position.x, desired.x, min(1.0, delta * 8.0))
    camera.global_position.y = lerp(camera.global_position.y, desired.y, min(1.0, delta * 7.0))
    camera.global_position.z = desired.z
    camera.look_at(player.global_position + Vector3(0.0, 1.25, -11.0), Vector3.UP)

    _recycle_road()
    _recycle_forest()
    if mountain_rig:
        mountain_rig.global_position.z = player.global_position.z - 520.0
        mountain_rig.global_position.x = sin(player.global_position.z * 0.002) * 18.0
    if cloud_rig:
        cloud_rig.global_position.z = player.global_position.z - 240.0

func _setup_lighting_and_sky() -> void:
    var env_node := WorldEnvironment.new()
    env_node.name = "WorldEnvironment"
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.75
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.glow_intensity = 0.7
    env.glow_bloom = 0.12
    env.fog_enabled = true
    env.fog_light_color = Color(0.42, 0.56, 0.61)
    env.fog_density = 0.0065
    env.fog_sky_affect = 0.38

    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.035, 0.08, 0.14)
    sky_mat.sky_horizon_color = Color(0.24, 0.40, 0.43)
    sky_mat.ground_bottom_color = Color(0.025, 0.06, 0.045)
    sky_mat.ground_horizon_color = Color(0.14, 0.24, 0.20)
    sky_mat.sun_angle_max = 18.0
    sky_mat.sun_curve = 0.08
    var sky := Sky.new()
    sky.sky_material = sky_mat
    env.sky = sky
    env_node.environment = env
    add_child(env_node)

    var sun := DirectionalLight3D.new()
    sun.name = "Sun"
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

    var fill := OmniLight3D.new()
    fill.name = "PurpleFill"
    fill.position = Vector3(0, 3.0, 4.0)
    fill.omni_range = 16.0
    fill.light_energy = 2.4
    fill.light_color = Color(0.55, 0.18, 0.95)
    add_child(fill)

func _build_road() -> void:
    var road_mat := StandardMaterial3D.new()
    road_mat.albedo_color = Color(0.055, 0.07, 0.065)
    road_mat.roughness = 0.92

    var line_mat := StandardMaterial3D.new()
    line_mat.albedo_color = Color(0.32, 0.035, 0.48)
    line_mat.emission_enabled = true
    line_mat.emission = Color(0.86, 0.06, 1.0)
    line_mat.emission_energy_multiplier = 4.0

    var edge_mat := StandardMaterial3D.new()
    edge_mat.albedo_color = Color(0.16, 0.03, 0.20)
    edge_mat.emission_enabled = true
    edge_mat.emission = Color(0.65, 0.04, 0.95)
    edge_mat.emission_energy_multiplier = 2.5

    for i in ROAD_SEGMENTS:
        var segment := Node3D.new()
        segment.name = "RoadSegment_%02d" % i
        segment.position = Vector3(0, 0, 25.0 - i * ROAD_LENGTH)
        add_child(segment)
        road_parts.append(segment)

        var road := MeshInstance3D.new()
        var road_mesh := BoxMesh.new()
        road_mesh.size = Vector3(9.0, 0.18, ROAD_LENGTH)
        road_mesh.material = road_mat
        road.mesh = road_mesh
        road.position.y = -0.12
        segment.add_child(road)

        var center := MeshInstance3D.new()
        var line_mesh := BoxMesh.new()
        line_mesh.size = Vector3(0.055, 0.04, ROAD_LENGTH)
        line_mesh.material = line_mat
        center.mesh = line_mesh
        center.position.y = -0.015
        segment.add_child(center)

        for side in [-1, 1]:
            var edge := MeshInstance3D.new()
            var edge_mesh := BoxMesh.new()
            edge_mesh.size = Vector3(0.08, 0.12, ROAD_LENGTH)
            edge_mesh.material = edge_mat
            edge.mesh = edge_mesh
            edge.position = Vector3(side * 4.3, -0.02, 0)
            segment.add_child(edge)

func _recycle_road() -> void:
    var min_z := 25.0
    for segment in road_parts:
        min_z = min(min_z, segment.global_position.z)
    for segment in road_parts:
        if segment.global_position.z > player.global_position.z + ROAD_LENGTH * 0.6:
            segment.global_position.z = min_z - ROAD_LENGTH
            min_z = segment.global_position.z

func _build_forest() -> void:
    for i in FOREST_SEGMENTS:
        var part := Node3D.new()
        part.name = "Forest_%02d" % i
        part.global_position = Vector3(0, 0, 8.0 - i * FOREST_LENGTH)
        add_child(part)
        _populate_forest_segment(part, i)
        forest_parts.append(part)

func _populate_forest_segment(part: Node3D, index: int) -> void:
    var local_rng := RandomNumberGenerator.new()
    local_rng.seed = 4000 + index * 97
    for side in [-1, 1]:
        var tree_x := side * local_rng.randf_range(6.0, 10.0)
        var tree_z := local_rng.randf_range(-FOREST_LENGTH * 0.45, FOREST_LENGTH * 0.45)
        _make_tree(part, Vector3(tree_x, 0, tree_z), local_rng)
        if local_rng.randf() > 0.32:
            var tree2_x := side * local_rng.randf_range(9.0, 13.5)
            var tree2_z := local_rng.randf_range(-FOREST_LENGTH * 0.45, FOREST_LENGTH * 0.45)
            _make_tree(part, Vector3(tree2_x, 0, tree2_z), local_rng)
        var rock_x := side * local_rng.randf_range(5.8, 9.5)
        var rock_z := local_rng.randf_range(-FOREST_LENGTH * 0.5, FOREST_LENGTH * 0.5)
        _make_rock(part, Vector3(rock_x, 0, rock_z), local_rng)

func _make_tree(parent: Node3D, pos: Vector3, local_rng: RandomNumberGenerator) -> void:
    var tree := Node3D.new()
    tree.position = pos
    tree.rotation.y = local_rng.randf_range(-0.7, 0.7)
    parent.add_child(tree)

    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.18
    trunk_mesh.bottom_radius = 0.28
    trunk_mesh.height = 2.6
    trunk_mesh.radial_segments = 8
    var trunk_mat := StandardMaterial3D.new()
    trunk_mat.albedo_color = Color(0.18, 0.11, 0.065)
    trunk_mat.roughness = 1.0
    trunk_mesh.material = trunk_mat
    trunk.mesh = trunk_mesh
    trunk.position.y = 1.25
    tree.add_child(trunk)

    var leaf_mat := StandardMaterial3D.new()
    leaf_mat.albedo_color = Color(0.055, 0.24, 0.11)
    leaf_mat.roughness = 0.95

    for j in 3:
        var crown := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        sphere.radius = 0.95 - j * 0.08
        sphere.height = 1.8 - j * 0.10
        sphere.radial_segments = 10
        sphere.rings = 6
        sphere.material = leaf_mat
        crown.mesh = sphere
        crown.position = Vector3((j - 1) * 0.35, 2.4 + j * 0.62, 0)
        crown.scale = Vector3(1.0 + local_rng.randf_range(-0.12, 0.12), 0.9 + local_rng.randf_range(-0.1, 0.14), 1.0 + local_rng.randf_range(-0.12, 0.12))
        tree.add_child(crown)

func _make_rock(parent: Node3D, pos: Vector3, local_rng: RandomNumberGenerator) -> void:
    var rock := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    var s := local_rng.randf_range(0.35, 0.8)
    sphere.radius = s
    sphere.height = s * 1.45
    sphere.radial_segments = 9
    sphere.rings = 5
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.23, 0.27, 0.25)
    mat.roughness = 1.0
    sphere.material = mat
    rock.mesh = sphere
    rock.position = pos + Vector3(0, s * 0.52, 0)
    rock.scale = Vector3(1.3, 0.8, 1.1)
    rock.rotation_degrees = Vector3(local_rng.randf_range(-14, 14), local_rng.randf_range(0, 360), local_rng.randf_range(-14, 14))
    parent.add_child(rock)

func _recycle_forest() -> void:
    var min_z := 8.0
    for part in forest_parts:
        min_z = min(min_z, part.global_position.z)
    for part in forest_parts:
        if part.global_position.z > player.global_position.z + 40.0:
            part.global_position.z = min_z - FOREST_LENGTH
            for child in part.get_children():
                child.free()
            var idx := int(str(part.name).split("_")[1])
            _populate_forest_segment(part, idx + int(distance_m / FOREST_LENGTH))
            min_z = part.global_position.z

func _build_mountaintops() -> void:
    mountain_rig = Node3D.new()
    mountain_rig.name = "DistantMountains"
    mountain_rig.global_position = Vector3(0, 0, -520)
    add_child(mountain_rig)

    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.035, 0.10, 0.12)
    mat.roughness = 1.0

    var shapes := [Vector3(-75, 0, 0), Vector3(0, 0, -12), Vector3(72, 0, 8)]
    var scales := [Vector3(1.15, 1.25, 1.10), Vector3(1.55, 1.70, 1.35), Vector3(1.25, 1.35, 1.25)]
    for i in shapes.size():
        var m := MeshInstance3D.new()
        var mesh := CylinderMesh.new()
        mesh.top_radius = 0.0
        mesh.bottom_radius = 46.0
        mesh.height = 86.0
        mesh.radial_segments = 9
        mesh.material = mat
        m.mesh = mesh
        m.position = shapes[i]
        m.scale = scales[i]
        mountain_rig.add_child(m)

func _build_clouds() -> void:
    cloud_rig = Node3D.new()
    cloud_rig.name = "Clouds"
    cloud_rig.global_position = Vector3(0, 58, -240)
    add_child(cloud_rig)

    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.80, 0.88, 0.90, 0.78)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.roughness = 1.0

    for c in 6:
        var cloud := Node3D.new()
        cloud.position = Vector3(-50 + c * 20, rng.randf_range(-4, 7), rng.randf_range(-35, 35))
        cloud.scale = Vector3(rng.randf_range(0.8, 1.7), rng.randf_range(0.35, 0.6), rng.randf_range(0.9, 1.4))
        cloud_rig.add_child(cloud)
        for p in 4:
            var puff := MeshInstance3D.new()
            var sphere := SphereMesh.new()
            sphere.radius = rng.randf_range(4.0, 7.0)
            sphere.height = rng.randf_range(5.0, 7.5)
            sphere.radial_segments = 10
            sphere.rings = 6
            sphere.material = mat
            puff.mesh = sphere
            puff.position = Vector3((p - 1.5) * 4.2, rng.randf_range(-0.6, 0.6), rng.randf_range(-1.7, 1.7))
            cloud.add_child(puff)

func _build_ui() -> void:
    var ui := CanvasLayer.new()
    ui.name = "UI"
    add_child(ui)

    var top := PanelContainer.new()
    top.position = Vector2(24, 28)
    top.size = Vector2(672, 86)
    var top_style := StyleBoxFlat.new()
    top_style.bg_color = Color(0.02, 0.03, 0.04, 0.86)
    top_style.border_width_left = 1
    top_style.border_width_top = 1
    top_style.border_width_right = 1
    top_style.border_width_bottom = 1
    top_style.border_color = Color(0.39, 0.23, 0.49, 0.75)
    top_style.corner_radius_top_left = 18
    top_style.corner_radius_top_right = 18
    top_style.corner_radius_bottom_left = 18
    top_style.corner_radius_bottom_right = 18
    top.add_theme_stylebox_override("panel", top_style)
    ui.add_child(top)

    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 16)
    row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    row.offset_left = 22
    row.offset_right = -22
    row.offset_top = 12
    row.offset_bottom = -12
    top.add_child(row)

    var title := Label.new()
    title.text = "NIGHT RUNNER  •  WILD"
    title.add_theme_font_size_override("font_size", 21)
    title.add_theme_color_override("font_color", Color(0.90, 0.92, 0.95))
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    row.add_child(title)

    distance_label = Label.new()
    distance_label.text = "0000 m"
    distance_label.add_theme_font_size_override("font_size", 20)
    distance_label.add_theme_color_override("font_color", Color(0.71, 0.46, 1.0))
    distance_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    row.add_child(distance_label)

    var left := _make_button("‹", Vector2(34, 1088), Vector2(170, 92), 44)
    var right := _make_button("›", Vector2(516, 1088), Vector2(170, 92), 44)
    var jump_btn := _make_button("JUMP", Vector2(210, 1070), Vector2(140, 92), 17)
    var slide_btn := _make_button("SLIDE", Vector2(370, 1070), Vector2(140, 92), 17)
    ui.add_child(left); ui.add_child(right); ui.add_child(jump_btn); ui.add_child(slide_btn)
    left.pressed.connect(player.move_left)
    right.pressed.connect(player.move_right)
    jump_btn.pressed.connect(player.jump)
    slide_btn.pressed.connect(player.slide)

    hint_label = Label.new()
    hint_label.text = "SWIPE  ←  →     ↑ JUMP     ↓ SLIDE"
    hint_label.position = Vector2(85, 1190)
    hint_label.size = Vector2(550, 36)
    hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint_label.add_theme_font_size_override("font_size", 13)
    hint_label.add_theme_color_override("font_color", Color(0.84, 0.87, 0.90, 0.78))
    ui.add_child(hint_label)
    get_tree().create_timer(4.0).timeout.connect(func(): hint_label.modulate.a = 0.0)

func _make_button(text: String, pos: Vector2, size: Vector2, font_size: int) -> Button:
    var b := Button.new()
    b.text = text
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", font_size)
    b.focus_mode = Control.FOCUS_NONE
    b.mouse_filter = Control.MOUSE_FILTER_STOP
    return b
