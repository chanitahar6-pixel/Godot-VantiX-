extends Node3D

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Player/Camera3D
@onready var distance_label: Label = $UI/TopBar/Distance
@onready var left_button: Button = $UI/Left
@onready var right_button: Button = $UI/Right
@onready var jump_button: Button = $UI/Jump
@onready var slide_button: Button = $UI/Slide

var road_parts: Array[Node3D] = []
var forest_parts: Array[Node3D] = []
var last_distance := 0.0
const ROAD_LEN := 45.0
const FOREST_LEN := 30.0

func _ready() -> void:
    left_button.pressed.connect(player.move_left)
    right_button.pressed.connect(player.move_right)
    jump_button.pressed.connect(player.jump)
    slide_button.pressed.connect(player.slide)

    for n in get_tree().get_nodes_in_group("road_segment"):
        road_parts.append(n)
    for n in get_tree().get_nodes_in_group("forest_chunk"):
        forest_parts.append(n)

func _process(delta: float) -> void:
    if is_instance_valid(distance_label):
        distance_label.text = "%04d m" % int(max(0.0, -player.global_position.z))

    _recycle_road()
    _recycle_forest()

func _recycle_road() -> void:
    if road_parts.is_empty():
        return
    var furthest := player.global_position.z - 120.0
    for part in road_parts:
        if part.global_position.z < furthest:
            furthest = part.global_position.z
    for part in road_parts:
        if part.global_position.z > player.global_position.z + 28.0:
            part.global_position.z = furthest - ROAD_LEN
            furthest = part.global_position.z

func _recycle_forest() -> void:
    if forest_parts.is_empty():
        return
    var furthest := player.global_position.z - 90.0
    for part in forest_parts:
        furthest = min(furthest, part.global_position.z)

    for part in forest_parts:
        if part.global_position.z > player.global_position.z + 24.0:
            part.global_position.z = furthest - FOREST_LEN
            furthest = part.global_position.z
            _randomize_chunk(part)

func _randomize_chunk(part: Node3D) -> void:
    var rng := RandomNumberGenerator.new()
    rng.randomize()
    for child in part.get_children():
        if child is Node3D:
            child.position.x = child.position.x + rng.randf_range(-1.1, 1.1)
            child.position.z = rng.randf_range(-12.0, 12.0)
            child.rotation.y = rng.randf_range(-3.14, 3.14)
            var s := rng.randf_range(0.82, 1.24)
            child.scale = Vector3(s, s * rng.randf_range(0.88, 1.18), s)
