extends Node3D

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Camera3D
@onready var distance_label: Label = $UI/TopBar/Margin/Row/Distance
@onready var left_button: Button = $UI/LeftButton
@onready var right_button: Button = $UI/RightButton

var distance_m := 0.0
var touch_start := Vector2.ZERO
var touch_active := false

func _ready() -> void:
    left_button.pressed.connect(_on_left)
    right_button.pressed.connect(_on_right)

func _process(delta: float) -> void:
    if is_instance_valid(player):
        distance_m += max(0.0, -player.velocity.z) * delta
        distance_label.text = "%04d m" % int(distance_m)

        var desired := player.global_position + Vector3(0, 2.65, 6.4)
        camera.global_position = camera.global_position.lerp(desired, min(1.0, delta * 5.0))
        camera.look_at(player.global_position + Vector3(0, 1.0, -3.0), Vector3.UP)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            touch_start = event.position
            touch_active = true
        elif touch_active:
            var delta := event.position - touch_start
            touch_active = false
            if abs(delta.x) >= 55.0:
                if delta.x < 0:
                    _on_left()
                else:
                    _on_right()

func _on_left() -> void:
    if is_instance_valid(player):
        player.move_left()

func _on_right() -> void:
    if is_instance_valid(player):
        player.move_right()
