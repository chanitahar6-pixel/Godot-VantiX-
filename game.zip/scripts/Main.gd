extends Node3D

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $Camera3D
@onready var score_label: Label = $UI/Score
@onready var distance_label: Label = $UI/Distance
var score := 0
var start_z := 0.0

func _ready() -> void:
    start_z = player.global_position.z
    for coin in $Coins.get_children():
        if coin.has_signal("collected"):
            coin.collected.connect(_on_coin_collected)

func _process(_delta: float) -> void:
    # Smooth chase camera so the runner stays centered.
    var target = player.global_position + Vector3(0.0, 5.2, 8.8)
    camera.global_position = camera.global_position.lerp(target, 0.12)
    camera.look_at(player.global_position + Vector3(0, 1.4, -7), Vector3.UP)
    var meters = int(abs(player.global_position.z - start_z))
    distance_label.text = "DISTANCE  %dm" % meters

func _on_coin_collected() -> void:
    score += 1
    score_label.text = "SCORE  %d" % score

func _on_left_button_pressed() -> void:
    player.move_left()

func _on_right_button_pressed() -> void:
    player.move_right()
