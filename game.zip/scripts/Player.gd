extends CharacterBody3D

@export var forward_speed: float = 5.2
@export var lane_width: float = 2.25
@export var lane_change_speed: float = 9.0

var lane := 0
var _anim_player: AnimationPlayer

func _ready() -> void:
    _anim_player = _find_animation_player(self)
    if _anim_player:
        var clips := _anim_player.get_animation_list()
        var chosen := ""
        for clip in clips:
            var lower := clip.to_lower()
            if "walk" in lower or "strut" in lower or "run" in lower:
                chosen = clip
                break
        if chosen == "":
            for clip in clips:
                if clip.to_lower() != "reset":
                    chosen = clip
                    break
        if chosen != "":
            _anim_player.play(chosen)

func _physics_process(delta: float) -> void:
    velocity.z = -forward_speed

    var target_x := float(lane) * lane_width
    global_position.x = move_toward(global_position.x, target_x, lane_change_speed * delta)

    move_and_slide()

func move_left() -> void:
    lane = max(-1, lane - 1)

func move_right() -> void:
    lane = min(1, lane + 1)

func _find_animation_player(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node
    for child in node.get_children():
        var found := _find_animation_player(child)
        if found:
            return found
    return null
