extends CharacterBody3D

@export var forward_speed: float = 7.0
@export var lane_width: float = 2.05
@export var lane_change_speed: float = 11.0
@export var gravity: float = 22.0
@export var jump_velocity: float = 8.3
@export var slide_duration: float = 0.72

var lane := 0
var _anim_player: AnimationPlayer
var _model: Node3D
var _collider: CollisionShape3D
var _standing_shape: Shape3D
var _slide_shape: Shape3D
var _slide_left := 0.0
var _run_clip := ""
var _base_model_position := Vector3.ZERO
var _touch_start := Vector2.ZERO
var _touch_active := false

func _ready() -> void:
    process_priority = 20
    _model = get_node_or_null("Model")
    _collider = get_node_or_null("CollisionShape3D")
    if _collider:
        _standing_shape = _collider.shape
        var slide_shape := CapsuleShape3D.new()
        slide_shape.radius = 0.32
        slide_shape.height = 1.05
        _slide_shape = slide_shape
    _anim_player = _find_animation_player(self)
    _run_clip = _choose_run_clip()
    if _anim_player and _run_clip != "":
        _anim_player.play(_run_clip)
    if _model:
        _base_model_position = _model.position

func _physics_process(delta: float) -> void:
    velocity.z = -forward_speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif velocity.y < 0.0:
        velocity.y = -0.4

    var target_x := float(lane) * lane_width
    global_position.x = move_toward(global_position.x, target_x, lane_change_speed * delta)

    if _slide_left > 0.0:
        _slide_left -= delta
        if _slide_left <= 0.0:
            _end_slide()

    move_and_slide()

func _process(_delta: float) -> void:
    # Prevent FBX root-motion from making the visual character drift far ahead.
    if _model:
        _model.position.x = _base_model_position.x
        _model.position.z = _base_model_position.z

func move_left() -> void:
    lane = max(-1, lane - 1)

func move_right() -> void:
    lane = min(1, lane + 1)

func jump() -> void:
    if is_on_floor() and _slide_left <= 0.0:
        velocity.y = jump_velocity

func slide() -> void:
    if is_on_floor():
        if _slide_left <= 0.0:
            _begin_slide()
        _slide_left = slide_duration

func _begin_slide() -> void:
    if _collider and _slide_shape:
        _collider.shape = _slide_shape
        _collider.position.y = 0.53

func _end_slide() -> void:
    if _collider and _standing_shape:
        _collider.shape = _standing_shape
        _collider.position.y = 0.9

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _touch_start = event.position
            _touch_active = true
        elif _touch_active:
            var delta := event.position - _touch_start
            _touch_active = false
            if delta.length() >= 45.0:
                if abs(delta.x) > abs(delta.y):
                    if delta.x < 0.0:
                        move_left()
                    else:
                        move_right()
                else:
                    if delta.y < 0.0:
                        jump()
                    else:
                        slide()

func _choose_run_clip() -> String:
    if not _anim_player:
        return ""
    var fallback := ""
    for clip in _anim_player.get_animation_list():
        var lower := clip.to_lower()
        if lower == "reset":
            continue
        if fallback == "":
            fallback = clip
        if "walk" in lower or "run" in lower or "strut" in lower:
            return clip
    return fallback

func _find_animation_player(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node
    for child in node.get_children():
        var found := _find_animation_player(child)
        if found:
            return found
    return null
