extends CharacterBody3D

@export var forward_speed := 8.0
@export var lane_width := 3.0
@export var lane_change_speed := 12.0
var lane := 0
var run_t := 0.0

func _physics_process(delta: float) -> void:
    run_t += delta * 12.0

    if Input.is_action_just_pressed("ui_left"):
        lane = max(lane - 1, -1)
    if Input.is_action_just_pressed("ui_right"):
        lane = min(lane + 1, 1)

    var target_x := lane * lane_width
    global_position.x = move_toward(global_position.x, target_x, lane_change_speed * delta)
    velocity = Vector3(0.0, 0.0, -forward_speed)
    move_and_slide()
    _animate_run()

func move_left() -> void:
    lane = max(lane - 1, -1)

func move_right() -> void:
    lane = min(lane + 1, 1)

func _animate_run() -> void:
    var model = get_node_or_null("Model")
    if model == null:
        return
    var swing := sin(run_t) * 0.65
    var ll = model.get_node_or_null("Leg_L")
    var lr = model.get_node_or_null("Leg_R")
    var al = model.get_node_or_null("Arm_L")
    var ar = model.get_node_or_null("Arm_R")
    if ll: ll.rotation.x = swing
    if lr: lr.rotation.x = -swing
    if al: al.rotation.x = -swing
    if ar: ar.rotation.x = swing
