extends CharacterBody3D
@export var forward_speed := 7.0
@export var lane_width := 3.0
var lane := 0
var run_t := 0.0
func _physics_process(delta: float) -> void:
    run_t += delta * 10.0
    if Input.is_action_just_pressed("ui_left"): lane = max(lane-1,-1)
    if Input.is_action_just_pressed("ui_right"): lane = min(lane+1,1)
    var target_x = lane * lane_width
    velocity.x = (target_x-global_position.x)*7.0
    velocity.z = -forward_speed
    velocity.y = 0.0
    move_and_slide()
    _animate_run()
func _animate_run() -> void:
    var model = get_node_or_null("Model")
    if model == null: return
    var swing = sin(run_t) * 0.65
    for n in ["Leg_L","Leg_R","Arm_L","Arm_R"]:
        var part = model.get_node_or_null(n)
        if part: part.rotation.x = 0.0
    var ll = model.get_node_or_null("Leg_L")
    var lr = model.get_node_or_null("Leg_R")
    var al = model.get_node_or_null("Arm_L")
    var ar = model.get_node_or_null("Arm_R")
    if ll: ll.rotation.x = swing
    if lr: lr.rotation.x = -swing
    if al: al.rotation.x = -swing
    if ar: ar.rotation.x = swing
