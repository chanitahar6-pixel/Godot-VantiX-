extends CharacterBody3D

@export var forward_speed: float = 8.0
@export var lane_width: float = 3.0
@export var lane_change_speed: float = 12.0

var lane: int = 0
var run_t: float = 0.0

func _physics_process(delta: float) -> void:
    run_t += delta * 12.0

    if Input.is_action_just_pressed("ui_left"):
        move_left()
    if Input.is_action_just_pressed("ui_right"):
        move_right()

    var target_x := float(lane) * lane_width
    global_position.x = move_toward(global_position.x, target_x, lane_change_speed * delta)

    velocity = Vector3(0.0, 0.0, -forward_speed)
    move_and_slide()
    _animate_run()

func move_left() -> void:
    lane = max(lane - 1, -1)

func move_right() -> void:
    lane = min(lane + 1, 1)

func _animate_run() -> void:
    var swing := sin(run_t) * 0.65

    var ll := get_node_or_null("Leg_L")
    var lr := get_node_or_null("Leg_R")
    var al := get_node_or_null("Arm_L")
    var ar := get_node_or_null("Arm_R")
    var fl := get_node_or_null("Foot_L")
    var fr := get_node_or_null("Foot_R")

    if ll:
        ll.rotation.x = swing
    if lr:
        lr.rotation.x = -swing
    if al:
        al.rotation.x = -swing
    if ar:
        ar.rotation.x = swing
    if fl:
        fl.rotation.x = swing * 0.35
    if fr:
        fr.rotation.x = -swing * 0.35
