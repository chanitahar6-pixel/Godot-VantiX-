extends CharacterBody3D

@export var forward_speed: float = 9.0
@export var lane_width: float = 2.15
@export var lane_change_speed: float = 14.0
@export var gravity: float = 23.0
@export var jump_velocity: float = 9.0
@export var slide_duration: float = 0.72

var lane: int = 0
var vertical_velocity: float = 0.0
var slide_left: float = 0.0
var touch_start := Vector2.ZERO
var touch_active := false
var model: Node3D
var anim_player: AnimationPlayer
var run_clip := ""
var collider: CollisionShape3D
var standing_shape: Shape3D
var slide_shape: CapsuleShape3D
var model_base_pos := Vector3.ZERO
var model_base_scale := Vector3.ONE
var anim_time := 0.0

func _ready() -> void:
    model = get_node_or_null("Model")
    collider = get_node_or_null("CollisionShape3D")
    if model:
        model_base_pos = model.position
        model_base_scale = model.scale
    if collider:
        standing_shape = collider.shape
        slide_shape = CapsuleShape3D.new()
        slide_shape.radius = 0.34
        slide_shape.height = 1.05
    anim_player = _find_animation_player(self)
    run_clip = _find_run_clip()
    if anim_player and run_clip != "":
        anim_player.play(run_clip)
        anim_player.seek(0.0, true)

func _physics_process(delta: float) -> void:
    anim_time += delta

    global_position.z -= forward_speed * delta

    var target_x := float(lane) * lane_width
    global_position.x = move_toward(global_position.x, target_x, lane_change_speed * delta)

    vertical_velocity -= gravity * delta
    global_position.y += vertical_velocity * delta
    if global_position.y <= 0.0:
        global_position.y = 0.0
        vertical_velocity = 0.0

    if slide_left > 0.0:
        slide_left -= delta
        if slide_left <= 0.0:
            _end_slide()

    if model:
        # Keep the imported FBX attached to the runner root.
        model.position.x = model_base_pos.x
        model.position.z = model_base_pos.z
        if anim_player and run_clip != "":
            if not anim_player.is_playing():
                anim_player.play(run_clip)
        else:
            model.position.y = model_base_pos.y + sin(anim_time * 12.0) * 0.025

func move_left() -> void:
    lane = clampi(lane - 1, -1, 1)

func move_right() -> void:
    lane = clampi(lane + 1, -1, 1)

func jump() -> void:
    if global_position.y <= 0.03 and slide_left <= 0.0:
        vertical_velocity = jump_velocity

func slide() -> void:
    if global_position.y <= 0.03:
        if slide_left <= 0.0:
            _begin_slide()
        slide_left = slide_duration

func _begin_slide() -> void:
    if collider and slide_shape:
        collider.shape = slide_shape
        collider.position.y = 0.53
    if model:
        model.scale = Vector3(model_base_scale.x, model_base_scale.y * 0.68, model_base_scale.z)
        model.position.y = model_base_pos.y - 0.30

func _end_slide() -> void:
    if collider and standing_shape:
        collider.shape = standing_shape
        collider.position.y = 0.92
    if model:
        model.scale = model_base_scale
        model.position.y = model_base_pos.y

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            touch_start = event.position
            touch_active = true
        elif touch_active:
            touch_active = false
            var d := event.position - touch_start
            if d.length() >= 30.0:
                if abs(d.x) > abs(d.y):
                    if d.x < 0.0: move_left()
                    else: move_right()
                else:
                    if d.y < 0.0: jump()
                    else: slide()

    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_LEFT, KEY_A: move_left()
            KEY_RIGHT, KEY_D: move_right()
            KEY_UP, KEY_SPACE: jump()
            KEY_DOWN, KEY_S: slide()

func _find_animation_player(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node
    for child in node.get_children():
        var found := _find_animation_player(child)
        if found != null:
            return found
    return null

func _find_run_clip() -> String:
    if anim_player == null:
        return ""
    var fallback := ""
    for clip in anim_player.get_animation_list():
        var name_lower := clip.to_lower()
        if name_lower == "reset":
            continue
        if fallback == "":
            fallback = clip
        if "walk" in name_lower or "run" in name_lower or "strut" in name_lower:
            return clip
    return fallback
