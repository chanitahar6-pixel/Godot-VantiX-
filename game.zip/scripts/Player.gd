extends CharacterBody3D

@export var forward_speed: float = 8.2
@export var lane_width: float = 2.05
@export var lane_change_speed: float = 12.5
@export var gravity: float = 22.0
@export var jump_velocity: float = 8.8
@export var slide_duration: float = 0.72
@export var ground_y: float = 0.0

var lane: int = 0
var vertical_velocity: float = 0.0
var _slide_left: float = 0.0
var _touch_start := Vector2.ZERO
var _touch_active := false
var _model: Node3D
var _anim_player: AnimationPlayer
var _run_clip := ""
var _collider: CollisionShape3D
var _standing_shape: Shape3D
var _slide_shape: Shape3D
var _model_base_pos := Vector3.ZERO
var _model_base_scale := Vector3.ONE
var _run_time := 0.0

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _model = get_node_or_null("Model")
    _collider = get_node_or_null("CollisionShape3D")
    if _model:
        _model_base_pos = _model.position
        _model_base_scale = _model.scale

    if _collider:
        _standing_shape = _collider.shape
        var s := CapsuleShape3D.new()
        s.radius = 0.34
        s.height = 1.05
        _slide_shape = s

    _anim_player = _find_animation_player(self)
    _run_clip = _choose_run_clip()
    if _anim_player and _run_clip != "":
        _anim_player.play(_run_clip)

func _physics_process(delta: float) -> void:
    _run_time += delta

    # Guaranteed runner motion: direct transform movement avoids physics-floor deadlocks
    # on different Android/Godot export configurations.
    global_position.z -= forward_speed * delta

    var target_x := float(lane) * lane_width
    global_position.x = move_toward(global_position.x, target_x, lane_change_speed * delta)

    vertical_velocity -= gravity * delta
    global_position.y += vertical_velocity * delta
    if global_position.y <= ground_y:
        global_position.y = ground_y
        if vertical_velocity < 0.0:
            vertical_velocity = 0.0

    if _slide_left > 0.0:
        _slide_left -= delta
        if _slide_left <= 0.0:
            _end_slide()

    _animate_fallback(delta)

func _process(_delta: float) -> void:
    # The FBX can carry root translation inside the scene hierarchy.
    # Keep its scene root visually attached to the runner while the parent moves.
    if _model:
        _model.position.x = _model_base_pos.x
        _model.position.z = _model_base_pos.z

func _animate_fallback(_delta: float) -> void:
    if not _model:
        return

    # Keep animation playing when the FBX contains a usable clip.
    if _anim_player and _run_clip != "":
        if _anim_player.is_playing() == false:
            _anim_player.play(_run_clip)
        return

    # Safe fallback when an imported animation is missing: a subtle run bob/lean
    # keeps the character visibly alive instead of freezing at the import pose.
    var phase := _run_time * 13.0
    _model.position.y = _model_base_pos.y + sin(phase) * 0.035
    _model.rotation.z = sin(phase * 0.5) * 0.025

func move_left() -> void:
    lane = max(-1, lane - 1)

func move_right() -> void:
    lane = min(1, lane + 1)

func jump() -> void:
    if global_position.y <= ground_y + 0.02 and _slide_left <= 0.0:
        vertical_velocity = jump_velocity

func slide() -> void:
    if global_position.y <= ground_y + 0.02:
        if _slide_left <= 0.0:
            _begin_slide()
        _slide_left = slide_duration

func _begin_slide() -> void:
    if _collider and _slide_shape:
        _collider.shape = _slide_shape
        _collider.position.y = 0.52
    if _model:
        _model.scale = Vector3(_model_base_scale.x, _model_base_scale.y * 0.68, _model_base_scale.z)
        _model.position.y = _model_base_pos.y - 0.32

func _end_slide() -> void:
    if _collider and _standing_shape:
        _collider.shape = _standing_shape
        _collider.position.y = 0.92
    if _model:
        _model.scale = _model_base_scale
        _model.position.y = _model_base_pos.y

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _touch_start = event.position
            _touch_active = true
        elif _touch_active:
            _touch_active = false
            var delta := event.position - _touch_start
            if delta.length() >= 35.0:
                if abs(delta.x) > abs(delta.y):
                    if delta.x < 0.0:
                        move_left()
                    else:
                        move_right()
                else:
                    if delta.y < 0.0:
                        jump()
                    else:
                        slide()

    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_LEFT, KEY_A: move_left()
            KEY_RIGHT, KEY_D: move_right()
            KEY_SPACE, KEY_UP: jump()
            KEY_DOWN, KEY_S: slide()

func _choose_run_clip() -> String:
    if not _anim_player:
        return ""
    var fallback := ""
    for clip in _anim_player.get_animation_list():
        var lower := clip.to_lower()
        if lower == "reset":
            continue
        if fallback == "":
            fallback = clip
        if "walk" in lower or "run" in lower or "strut" in lower:
            return clip
    return fallback

func _find_animation_player(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node
    for child in node.get_children():
        var found := _find_animation_player(child)
        if found:
            return found
    return null
