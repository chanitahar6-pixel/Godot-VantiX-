extends Area3D
signal collected
var taken := false
func _ready() -> void:
    body_entered.connect(_on_body_entered)
func _process(delta: float) -> void:
    rotate_y(4.0*delta)
func _on_body_entered(body: Node3D) -> void:
    if taken: return
    if body.name == "Player":
        taken = true
        collected.emit()
        queue_free()
