# Night Runner — Real 3D Player Test

هذا الاختبار يركز على شخصية 3D حقيقية من Mixamo مع Skeleton/Animation داخل Godot.

المشروع لا يستخدم Gaea ولا سكربتات خارجية ولا موديلات مولدة من مربعات.
الشخصية موجودة في:
res://assets/Strut Walking.fbx

الهدف:
- التأكد من تحميل نموذج 3D الحقيقي داخل Android.
- التأكد من عمل AnimationPlayer والـwalk/strut animation.
- التأكد من حركة الشخصية وتغيير المسارات.
- واجهة Portrait مناسبة للهاتف.

بعد نجاحه يمكن إضافة بقية أنظمة اللعبة تدريجيًا.
