اختبار تشخيصي فقط.
لا يوجد فيه Gaea أو GLB أو Scripts أو Player أو Coins.
النتيجة المطلوبة: بعد شاشة Godot تظهر رسالة GAME STARTED SUCCESSFULLY.
