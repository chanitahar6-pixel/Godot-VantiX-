# Gaea Runner Game 🚀

هذا هو النموذج الحقيقي: رجل 3D مولّد كملف `assets/player/Player.glb`، مربوط داخل `Player.tscn`، يجري تلقائياً ويبدل المسارات ويجمع Coins ويزيد Score.

Gaea موجود داخل `addons/gaea` وجاهز للمراحل القادمة.

عند رفع المشروع إلى GitHub ثم push إلى `main`، ملف `.github/workflows/android.yml` يشغّل Godot headless ويصدر APK وفق Export preset اسمها `Android`. هذا يتوافق مع طريقة Godot الرسمية للتصدير من سطر الأوامر (`--export-debug/--export-release`)؛ الـpreset يجب أن تكون موجودة في `export_presets.cfg`.
