# Gaea Runner — مشروع جاهز للبناء 🚀

هذه نسخة بسيطة من لعبة ركض 3D:

- رجل 3D موجود في `assets/player/Player.glb`.
- الرجل يجري للأمام تلقائيًا.
- 3 مسارات.
- أزرار لمس LEFT / RIGHT، مع دعم الأسهم للاختبار.
- Coins قابلة للجمع.
- Score + Distance.
- كاميرا تتبع اللاعب.
- بيئة وطريق 3D تجريبي.
- Gaea موجود داخل `addons/gaea`.

## المطلوب منك

**لا تعدل الكود.** ارفع مجلد المشروع كاملًا إلى مستودع GitHub مع الحفاظ على `.github/workflows/android.yml`.

عند push إلى `main` يبدأ GitHub Actions تلقائيًا:

1. ينزل Godot 4.6.
2. ينزل Export Templates.
3. يجهز Android SDK وJava.
4. يبني APK.
5. يرفق APK داخل Artifacts باسم `GaeaRunner-APK`.

يمكن أيضًا تشغيله يدويًا من Actions عبر `workflow_dispatch`.

## هيكل مهم

`project.godot` — إعداد المشروع
`Main.tscn` — اللعبة الرئيسية
`Player.tscn` — اللاعب وربطه بالمجسم
`assets/player/Player.glb` — المجسم
`scripts/Player.gd` — الجري والمسارات
`scripts/Coin.gd` — جمع العملات
`scripts/Main.gd` — Score والكاميرا
`.github/workflows/android.yml` — البناء التلقائي
